//! Core constraint trait and supporting types.

use std::fmt::Debug;

use crate::domain::Domain;
use crate::variable::Variable;

/// Unique variable identifier (index into the variable array).
pub type VarId = u32;

/// Result of running `revise` on a constraint.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Revision {
    Unchanged,
    Changed,
    Unsatisfiable,
}

/// A constraint over one or more CSP variables.
///
/// `Send + Sync` so that `Box<dyn Constraint<D>>` (and therefore `Csp<D>` as a
/// whole) can cross the `pyo3::Python::allow_threads` boundary — every
/// built-in closure-based constraint (`add_equals`/`add_less_than`/
/// `add_greater_than`) only ever captures `Copy` primitives, so this is a
/// non-breaking, purely additive bound.
pub trait Constraint<D: Domain>: Debug + Send + Sync {
    /// The variables this constraint involves (its "scope").
    fn scope(&self) -> &[VarId];

    /// Check whether a full or partial assignment satisfies this constraint.
    fn check(&self, assignment: &[Option<D::Value>]) -> bool;

    /// AC-3 style revision: prune unsupported values from domains.
    ///
    /// Dispatches on scope size to the module-private `revise_unary_default`
    /// / `revise_binary_default` helpers below (n-ary constraints get their
    /// own devirtualized `revise_impl` — `AllDifferent`,
    /// `AllDifferentExcept` — the default here only needs to cover what
    /// `LambdaConstraint`/`Custom` actually construct: `add_equals` is
    /// unary, `add_less_than`/`add_greater_than` are binary).
    ///
    /// Previously scope.len() == 1 unconditionally returned `Unchanged` —
    /// silently disabling propagation for every unary constraint
    /// (`add_equals`), which was then enforced only by `check()` at
    /// assignment time (Pass-1 propagation audit, P2-1). Fixed below.
    fn revise(&self, vars: &mut [Variable<D>], depth: usize) -> Revision {
        match self.scope().len() {
            1 => revise_unary_default(self, vars, depth),
            2 => revise_binary_default(self, vars, depth),
            _ => Revision::Unchanged,
        }
    }
}

/// Default unary revision: prune every domain value unsupported by
/// `check()` in isolation. Iterates the domain's owned snapshot directly
/// (`Domain::iter`'s `+ use<Self>` bound), no heap `Vec`. A free function
/// (not a trait method) so it doesn't grow `Constraint`'s public surface —
/// it's purely `revise`'s own dispatch target.
fn revise_unary_default<D: Domain, C: Constraint<D> + ?Sized>(
    c: &C,
    vars: &mut [Variable<D>],
    depth: usize,
) -> Revision {
    let xi = c.scope()[0] as usize;
    let mut assignment: Vec<Option<D::Value>> = vec![None; vars.len()];
    let mut changed = false;

    for vi in vars[xi].domain.iter() {
        assignment[xi] = Some(vi.clone());
        if !c.check(&assignment) {
            vars[xi].prune(&vi, depth);
            changed = true;
        }
    }

    if vars[xi].domain.is_empty() {
        return Revision::Unsatisfiable;
    }

    if changed { Revision::Changed } else { Revision::Unchanged }
}

/// Default binary revision: the "change-mask" rewrite of the previous
/// 5-`Vec` implementation (one `vars.len()`-sized `assignment`, plus four
/// `domain.values()` snapshots — `vals_i`/`vals_j` each collected twice,
/// once per direction pass, per the Pass-1 constraint audit's F5).
///
/// The `assignment` scratch is kept (its size is dictated by
/// `Constraint::check`'s existing `&[Option<D::Value>]` contract, indexed
/// by absolute `VarId` — narrowing it would be a breaking signature change
/// reaching every hand-rolled `revise`/`check` in bbnf-lang's 11+ `Custom`
/// constraint types). The four domain snapshots are eliminated: each pass
/// calls `domain.iter()` fresh inside the loop instead of pre-collecting
/// into a `Vec` — for `BitsetDomain` (the crate's only production domain)
/// re-deriving the iterator is a cheap `u128` copy, not a re-scan, so this
/// costs nothing extra while dropping 4 allocations to 0. The second
/// pass's `vals_i` must still reflect pass 1's pruning (correctness-
/// critical: pass 1 may have narrowed `xi`), which a live
/// `vars[xi].domain.iter()` gives for free — no explicit re-collection
/// needed.
fn revise_binary_default<D: Domain, C: Constraint<D> + ?Sized>(
    c: &C,
    vars: &mut [Variable<D>],
    depth: usize,
) -> Revision {
    let scope = c.scope();
    let xi = scope[0] as usize;
    let xj = scope[1] as usize;
    let mut changed = false;

    let mut assignment: Vec<Option<D::Value>> = vec![None; vars.len()];

    for vi in vars[xi].domain.iter() {
        let mut supported = false;
        assignment[xi] = Some(vi.clone());
        for vj in vars[xj].domain.iter() {
            assignment[xj] = Some(vj);
            if c.check(&assignment) {
                supported = true;
                break;
            }
        }
        if !supported {
            vars[xi].prune(&vi, depth);
            changed = true;
        }
    }
    assignment[xi] = None;
    assignment[xj] = None;

    if vars[xi].domain.is_empty() {
        return Revision::Unsatisfiable;
    }

    for vj in vars[xj].domain.iter() {
        let mut supported = false;
        assignment[xj] = Some(vj.clone());
        for vi in vars[xi].domain.iter() {
            assignment[xi] = Some(vi);
            if c.check(&assignment) {
                supported = true;
                break;
            }
        }
        if !supported {
            vars[xj].prune(&vj, depth);
            changed = true;
        }
    }

    if vars[xj].domain.is_empty() {
        return Revision::Unsatisfiable;
    }

    if changed { Revision::Changed } else { Revision::Unchanged }
}

/// A constraint with a penalty for violation.
///
/// Hard constraints prune domains; soft constraints contribute cost to the
/// objective when violated. During optimization, the solver accumulates
/// penalties from violated soft constraints alongside domain costs.
pub trait SoftConstraint<D: Domain>: Constraint<D> {
    /// Penalty added to the objective when this constraint is violated.
    fn penalty(&self) -> f64;
}
